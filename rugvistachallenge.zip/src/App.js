import './App.css';
import rugvista from "./RugVista.json";
import 'bootstrap/dist/css/bootstrap.min.css'

/* import {Button, Alert, Breadcrumb, Card, Form } from 'react-bootstrap' */

function App() {
  function strikeThrough() {
    /* console.log("testing") */
    /* document.getElementById('testar').style.textDecoration= "line-through"; */
    var element = document.getElementById("strikeThrough");
    element.classList.toggle("setStyle");
  }
  return (
    
    <div className="App container w-50 p-3">
    <header className="App-header">
      <div className="posts">
{/*         <Form>
          <Form.Label>Email Address</Form.Label>
          <Form.Control type="email" placeholder="example@gmasd.se"></Form.Control>
          <Form.Text className="text-muted">
            Alltid privat
          </Form.Text>
        </Form>
        <Card className="mb-3" style={{ color: "#000"}}>
          <Card.Img src="https://picsum.photos/seed/picsum/200/100" />
          <Card.Body>
            <Card.Title>
              Card Example
            </Card.Title>
            <Card.Text>
              This is an example
            </Card.Text>
            <Button variant="primary">Detta är test knapp</Button>
          </Card.Body>
        </Card>
        <Breadcrumb>
          <Breadcrumb.Item>Test</Breadcrumb.Item> 
          <Breadcrumb.Item>Test 2</Breadcrumb.Item>
          <Breadcrumb.Item active>Test 3</Breadcrumb.Item>
        </Breadcrumb>
        <Alert variant="secondary">This is a button</Alert>
        <Button>Test</Button> */}
        {
          <div>
          <h4>{ rugvista.name }</h4>
          <div>{ rugvista.items.map(rugvista=>{
            return(
              <div className="list-group" key={rugvista.id} id="strikeThrough">
                <label className="list-group-item">
                  <input onClick={strikeThrough}  className="form-check-input me-1" type="checkbox" required/>
                  {rugvista.title}<br/>{rugvista.subtitle}
                </label>
              </div>
            )
          })}</div>
          </div>
        }
      </div>
    </header>
  </div>
  );
}


export default App;
